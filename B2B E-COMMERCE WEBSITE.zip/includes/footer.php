<div class="bg-info p-3 text-center">
    <p>All rights reserved 	&#9400; Designed by Ekram Shethil-2023</p>
</div>